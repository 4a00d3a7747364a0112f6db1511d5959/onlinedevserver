<?php
/*
* The template for inner pages
*/
get_header(); ?>

<!-- bamboo diapers -->
<section class="bamboo_diapers clearfix">
  	<div class="container">
		<h2 style="text-align: center; font-size: 18px;">Magical Moments with Dewor Baby on Instagram <span>@DeworBaby</span></h2>

		<ul id="sb_custom_instafeeds"></ul>			    
  	</div>
</section>
<!-- bamboo diapers end -->

<?php get_footer(); ?>