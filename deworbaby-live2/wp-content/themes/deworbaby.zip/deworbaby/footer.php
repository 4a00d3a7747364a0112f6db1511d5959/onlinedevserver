<?php
/*
* The template for displaying the footer
*/
global $deworbaby_options; 
?>

<!-- footer -->
<footer>
	<div class="container">
		<div class="fooWrap">
			<?php 
				wp_nav_menu( 
					array( 'container' => 'ul', 'menu_class' => '', 'menu_id' => '', 'theme_location' => 'footer-menu', 'link_before' => '<span>', 'link_after' => '</span>', )
				); 
			?>
			<p>Copyright &copy; <?php echo date('Y'); ?> <?php echo $deworbaby_options['copyright']; ?></p>
		</div>
	</div>
</footer>
<!-- footer ends-->

<?php wp_footer(); ?>
</body>
</html>