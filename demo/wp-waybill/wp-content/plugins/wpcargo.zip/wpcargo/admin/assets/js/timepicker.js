jQuery(document).ready(function($){
//Date
	var nf = $.noConflict();
	nf('#datetimepicker2').timepicker({'ampm': true });
	nf('#datetimepicker5').timepicker({'ampm': true });
	nf('#datetimepicker7').timepicker({'ampm': true });
});