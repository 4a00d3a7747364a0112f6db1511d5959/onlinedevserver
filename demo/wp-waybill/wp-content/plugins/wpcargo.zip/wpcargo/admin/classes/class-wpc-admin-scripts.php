<?php
if ( ! defined( 'ABSPATH' ) ) {

	exit;

}
class WPCargo_Admin_Scripts{

	public function __construct(){

		add_action( 'admin_init', array( $this,'admin_scripts' ) );

	}

	public function admin_scripts() {

		wp_register_script('wpcargo-timepicker-js', WPCARGO_PLUGIN_URL . 'admin/assets/js/timepicker.js', array( 'jquery'), '1.0.0', TRUE );

		wp_register_script('wpcargo-timepicker', WPCARGO_PLUGIN_URL . 'admin/assets/js/jquery.timepicker.js', array( 'jquery' ), '1.0.0', TRUE );

		wp_enqueue_script('wpcargo-timepicker-js');

		wp_enqueue_script('wpcargo-timepicker');

		wp_enqueue_script('jquery-ui-datepicker');

		wp_register_style('wpcargo-timepicker-css', WPCARGO_PLUGIN_URL . 'admin/assets/css/jquery.timepicker.css', '1.0.0');

		wp_enqueue_style('wpcargo-timepicker-css');

		wp_register_script('wpcargo-bootstrap-min-js', 'http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js', array( 'jquery' ), '1.0.0');

		wp_register_style('wpcargo-bootstrap-min-css', WPCARGO_PLUGIN_URL . 'admin/assets/css/wpcargo-bootstrap.min.css', '1.0.0');

		wp_register_style('wpcargo-admin-css', WPCARGO_PLUGIN_URL . 'admin/assets/css/admin-style.css', '1.0.0');

		wp_register_style('wpcargo-datepicker-ui', WPCARGO_PLUGIN_URL . 'admin/assets/css/datepicker.css', '1.0.0');

		wp_enqueue_style('wpcargo-admin-css');

		wp_enqueue_style('wpcargo-datepicker-ui');
		if(isset( $_GET['page'] ) && $_GET['page'] == 'wpcargo-settings' ){

			wp_enqueue_media();

		}

	}

}

new WPCargo_Admin_Scripts;