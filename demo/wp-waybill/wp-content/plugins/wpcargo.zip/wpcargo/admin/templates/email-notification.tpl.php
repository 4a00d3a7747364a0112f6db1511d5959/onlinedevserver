<?php



$options = get_option('wpcargo_mail_settings');



if (!empty($options['wpcargo_active_mail'])) {



	$current_status	= isset($_REQUEST['wpcargo_status']) ? $_REQUEST['wpcargo_status'] : '';

	

	$last_status 	= get_option('wpcargo_status_req');



	$wpcargo_tn		= get_the_title($post_id);



	$shipper_email  = get_post_meta($post_id, 'wpcargo_shipper_email', true);



	$receiver_email = get_post_meta($post_id, 'wpcargo_receiver_email', true);



	$shipper_phone  = get_post_meta($post_id, 'wpcargo_shipper_phone', true);



	$receiver_phone = get_post_meta($post_id, 'wpcargo_receiver_phone', true);



	$admin_email    = get_option('admin_email');



	$shipper_name   = get_post_meta($post_id, 'wpcargo_shipper_name', true);



	$receiver_name  = get_post_meta($post_id, 'wpcargo_receiver_name', true);



	$status         = get_post_meta($post_id, 'wpcargo_status', true);



	$str_find       = array(



		'{wpcargo_tracking_number}',



		'{shipper_email}',



		'{receiver_email}',



		'{shipper_phone}',



		'{receiver_phone}',



		'{admin_email}',



		'{shipper_name}',



		'{receiver_name}',



		'{status}'



	);



	$str_replce     = array(



		$wpcargo_tn,



		$shipper_email,



		$receiver_email,



		$shipper_phone,



		$receiver_phone,



		$admin_email,



		$shipper_name,



		$receiver_name,



		$status



	);



	$headers        = 'From: ' . $options['wpcargo_mail_header'];



	$subject        = $options['wpcargo_mail_subject'];



	$message        = str_replace($str_find, $str_replce, $options['wpcargo_mail_message']);	



	$send_to        = str_replace($str_find, $str_replce, $options['wpcargo_mail_to']);	



	if( $current_status != $last_status && !empty($last_status) ) {



		wp_mail( $send_to, $subject, $message, $headers );



	}



}