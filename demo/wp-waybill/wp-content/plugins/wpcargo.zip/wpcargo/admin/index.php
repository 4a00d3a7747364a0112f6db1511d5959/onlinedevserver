<?php
// Silence is Golden